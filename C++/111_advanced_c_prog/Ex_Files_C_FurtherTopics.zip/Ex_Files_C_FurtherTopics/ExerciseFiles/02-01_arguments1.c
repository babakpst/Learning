#include <stdio.h>

int main(int argc, char *argv[])
{
	printf("There were %d command line arguments\n",argc);

	return(0);
}

