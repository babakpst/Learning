#include <stdio.h>

int main()
{
	int a;

	a = 5 + 20 * 2 - 8 / 2;
	printf("The answer is %d\n",a);

	return(0);
}

