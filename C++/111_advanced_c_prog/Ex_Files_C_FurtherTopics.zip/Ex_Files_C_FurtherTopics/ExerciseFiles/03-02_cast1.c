#include <stdio.h>
#include <math.h>

int main()
{
	int a,b;
	float c;

	a = 10; b = 3;
	c = a/b;
	printf("%d/%d = %.2f\n",a,b,c);

	return(0);
}

