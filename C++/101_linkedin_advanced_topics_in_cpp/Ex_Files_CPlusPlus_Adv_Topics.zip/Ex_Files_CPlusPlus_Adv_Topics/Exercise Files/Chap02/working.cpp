// working.cpp by Bill Weinman <http://bw.org/>
// updated 2018-10-04
#include <cstdio>

int main() {
    std::puts("Hello, World!");
    return 0;
}
