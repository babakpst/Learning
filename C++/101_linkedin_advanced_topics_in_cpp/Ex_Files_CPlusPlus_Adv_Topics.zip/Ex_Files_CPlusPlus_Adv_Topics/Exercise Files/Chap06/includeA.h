// includeA.h by Bill Weinman <http://bw.org/>
// updated 2018-10-10

#include "includeB.h"

struct structA {
    int member;
};

