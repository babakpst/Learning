// working.cpp by Bill Weinman <http://bw.org/>
// updated 2018-10-10
#include <cstdio>

int main() {
    puts("Hello, World!");
    return 0;
}
