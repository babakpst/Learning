// conditional.cpp by Bill Weinman <http://bw.org/>
// updated 2018-10-10
#include <stdio.h>
#include "conditional.h"

int main() {
    printf("Number is %d\n", _NUMBER);
    return 0;
}
