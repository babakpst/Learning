// includeB.h by Bill Weinman <http://bw.org/>
// updated 2018-10-10

#include "includeA.h"

struct structB {
    int member;
};

