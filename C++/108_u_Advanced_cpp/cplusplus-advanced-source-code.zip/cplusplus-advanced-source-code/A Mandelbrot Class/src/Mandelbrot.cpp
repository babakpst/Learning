/*
 * Mandelbrot.cpp
 *
 *  Created on: Aug 21, 2015
 *      Author: johnpurcell
 */

#include "Mandelbrot.h"

namespace caveofprogramming {

Mandelbrot::Mandelbrot() {
	// TODO Auto-generated constructor stub

}

Mandelbrot::~Mandelbrot() {
	// TODO Auto-generated destructor stub
}

int Mandelbrot::getIterations(double x, double y) {

	return 0;
}

} /* namespace caveofprogramming */
