/*
 * FractalCreator.cpp
 *
 *  Created on: Sep 21, 2015
 *      Author: johnpurcell
 */

#include "FractalCreator.h"

namespace caveofprogramming {

FractalCreator::FractalCreator(int width, int height) {
	// TODO Auto-generated constructor stub

}

FractalCreator::~FractalCreator() {
}

void FractalCreator::calculateIteration() {
}

void FractalCreator::drawFractal() {
}

void FractalCreator::addZoom(const Zoom& zoom) {
}

void FractalCreator::writeBitmap(string name) {
}

} /* namespace caveofprogramming */
