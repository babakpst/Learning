#
# Example file for working with functions
#

# define a basic function


# function that takes arguments


# function that returns a value


# function with default value for an argument


#function with variable number of arguments

