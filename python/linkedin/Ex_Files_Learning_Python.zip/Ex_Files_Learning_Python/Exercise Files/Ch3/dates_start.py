#
# Example file for working with date information
#


def main():
  ## DATE OBJECTS
  # Get today's date from the simple today() method from the date class


  # print out the date's individual components

  
  # retrieve today's weekday (0=Monday, 6=Sunday)

  
  ## DATETIME OBJECTS
  # Get today's date from the datetime class


  # Get the current time


  
if __name__ == "__main__":
  main();
  